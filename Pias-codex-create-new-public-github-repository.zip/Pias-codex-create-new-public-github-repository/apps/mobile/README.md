# Mobile

Flutter application for the Syndic suite.
