# API

Backend service built with NestJS, Prisma and PostgreSQL.
