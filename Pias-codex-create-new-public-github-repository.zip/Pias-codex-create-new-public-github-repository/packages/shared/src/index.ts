// Shared utilities and types will live here.
